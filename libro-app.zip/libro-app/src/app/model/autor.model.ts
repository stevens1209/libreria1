export interface Autor{
    idAutor: number;
    nombre: string;
    apellido: string;
    pais: string;
    direccion: Date;
    telefono: string;
    correo: string;
}