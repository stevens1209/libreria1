export interface Categoria {
    idCategoria: number;
    categoria: string;
    descripcion: string;
}